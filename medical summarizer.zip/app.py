import streamlit as st
from pathlib import Path
from utils.pdf_utils import extract_text_from_pdf
from utils.clinical_utils import structured_summary_from_text, generate_brief_condition_summary
from PIL import Image
import base64, io, tempfile

st.set_page_config(page_title="Medical Report Summarizer", layout="wide")

# Background image
BG_PATH = "pharma_bg.png"

def get_base64_of_bin_file(bin_file):
    with open(bin_file, 'rb') as f:
        data = f.read()
    return base64.b64encode(data).decode()

def set_background(png_file=BG_PATH):
    try:
        bin_str = get_base64_of_bin_file(png_file)
        page_bg_img = f"data:image/png;base64,{bin_str}"
        st.markdown(
            f"""
            <style>
            .stApp {{
                background-image: url("{page_bg_img}");
                background-size: cover;
                background-position: center;
            }}
            </style>
            """,
            unsafe_allow_html=True
        )
    except:
        pass

set_background()

# ------------------------------
# CUSTOM SUMMARY BOX COLOR HERE
# ------------------------------
st.markdown("""
<style>

/* Dark grey/black summary box */
.stAlert {
    background: #111111 !important;
    color: #ffffff !important;
    border-left: 5px solid #00C0FF !important; /* Cyan medical accent */
    padding: 20px !important;
    border-radius: 12px !important;
    font-size: 18px !important;
}

</style>
""", unsafe_allow_html=True)

# ------------------------------

st.title("Medical Report Summarizer")
st.write("Upload a PDF or image. The system gives a clear, simple patient-condition summary.")

uploaded = st.file_uploader("Upload report (PDF / image)", type=['pdf','png','jpg','jpeg'])
show_structured = st.checkbox("Show structured extraction (debug mode)", value=False)

if uploaded is not None:
    file_bytes = uploaded.read()

    temp_path = tempfile.mktemp(prefix="uploaded_", suffix=".tmp")
    with open(temp_path, "wb") as f:
        f.write(file_bytes)

    out_text = ""

    # PDF extraction
    if uploaded.name.lower().endswith(".pdf"):
        out_text = extract_text_from_pdf(temp_path)
    else:
        # Image OCR
        img = Image.open(io.BytesIO(file_bytes))
        from utils.ocr_utils import extract_text_from_image
        out_text = extract_text_from_image(img)

    if out_text:
        struct = structured_summary_from_text(out_text)
        bri = generate_brief_condition_summary(struct)

        st.subheader("Patient Condition Summary")
        st.success(bri.get("summary"))

        insights = bri.get("insights", [])
        if insights:
            st.subheader("Key Insights (Abnormal Findings)")
            for ins in insights:
                st.markdown(f"- **{ins}**")

        if show_structured:
            st.subheader("Structured Extracted Data")
            st.json(struct)

    else:
        st.warning("Could not extract text from the uploaded document.")
