import re
from typing import List, Dict, Any, Tuple

# Canonical test recognition
CANONICAL_TESTS = {
    r"\b(?:hb|hgb|hemoglobin)\b": "Hemoglobin",
    r"\b(?:rbc|red blood cells)\b": "RBC",
    r"\b(?:wbc|white blood cells)\b": "WBC",
    r"\b(?:plt|platelet|platelets)\b": "Platelets",
    r"\b(?:creat|creatinine)\b": "Creatinine",
    r"\b(?:glucose|blood sugar)\b": "Glucose",
}

# Simple adult reference ranges (you can expand)
REFERENCE_RANGES = {
    "Hemoglobin": (13.5, 17.5, "g/dL"),
    "WBC": (4.0, 11.0, "x10^9/L"),
    "Platelets": (150, 450, "x10^9/L"),
    "Glucose": (70, 140, "mg/dL"),
    "Creatinine": (0.6, 1.3, "mg/dL"),
}

UNIT_RE = re.compile(
    r"(?P<value>-?\d{1,3}(?:[.,]\d+)?(?:\s*[-–]\s*\d{1,3}(?:[.,]\d+)?)?)\s*(?P<unit>[A-Za-z/0-9\^\%]+)?",
    flags=re.IGNORECASE,
)

TEST_LINE_RE = re.compile(r"(?P<test>[A-Za-z0-9\-\s\./\(\)]+?)\s*[:\-]\s*(?P<rest>.+)", flags=re.IGNORECASE)

HEADING_WORDS = [
    "impression", "diagnosis", "final diagnosis", "discharge diagnosis",
    "conclusion", "assessment", "clinical summary"
]

# Noise patterns (ignore stack traces and UI text)
NOISE_PATTERNS = [
    r"traceback", r"filenotfounderror", r"exception", r"error:", r"copy askgoogle", r"ask chatgpt",
    r"file \"", r"http[s]?://", r"page not found", r"pharma", r"uploaded_report", r"set_background",
    r"pharma_bg.png"
]
NOISE_RE = re.compile("|".join(NOISE_PATTERNS), flags=re.IGNORECASE)


def is_noise_line(line: str) -> bool:
    if not line or len(line.strip()) < 3:
        return True
    if NOISE_RE.search(line):
        return True
    # lines that are mostly non-alpha (like long punctuation)
    alpha_ratio = sum(c.isalpha() for c in line) / max(1, len(line))
    if alpha_ratio < 0.2:
        return True
    return False


def canonicalize(name: str) -> str:
    name = name.strip()
    for pat, canon in CANONICAL_TESTS.items():
        if re.search(pat, name, flags=re.IGNORECASE):
            return canon
    return name.title()


def parse_value(val: str):
    if not val:
        return None
    v = val.replace("–", "-")
    if "-" in v:
        parts = v.split("-")
        try:
            nums = [float(p) for p in parts if re.search(r"\d", p)]
            if nums:
                return sum(nums) / len(nums)
        except:
            pass
    try:
        m = re.search(r"-?\d+(?:[.,]\d+)?", v)
        if m:
            return float(m.group(0).replace(",", ""))
    except:
        pass
    return None


def extract_tests_from_text(text: str):
    lines = text.splitlines()
    results = []

    for ln in lines:
        ln = ln.strip()
        if is_noise_line(ln):
            continue

        match = TEST_LINE_RE.match(ln)
        if match:
            raw_test = match.group("test")
            rest = match.group("rest")
            nums = UNIT_RE.search(rest)
            if nums:
                value = nums.group("value")
                unit = nums.group("unit") or ""
            else:
                value, unit = "", ""
            results.append({
                "name": raw_test,
                "canonical": canonicalize(raw_test),
                "value": value,
                "value_num": parse_value(value),
                "unit": unit,
            })
    return results


def extract_impression(text: str):
    lower = text.lower()
    for h in HEADING_WORDS:
        idx = lower.find(h)
        if idx != -1:
            block = text[idx: idx + 700]
            block = re.sub(h + r"[:\s\-]*", "", block, flags=re.IGNORECASE)
            return block.split("\n\n")[0].strip()
    return ""


def determine_type(text: str):
    t = text.lower()
    if any(w in t for w in ["cbc", "blood", "glucose", "hemoglobin"]):
        return "blood"
    if "discharge" in t:
        return "discharge"
    return "clinical"


def structured_summary_from_text(text: str):
    return {
        "report_type": determine_type(text),
        "impression": extract_impression(text),
        "tests": extract_tests_from_text(text)
    }


def interpret_abnormalities(tests):
    """
    Return a list of dicts: [{'test': name, 'flag': 'low'|'high', 'value': num, 'unit': unit}, ...]
    Always returns structured dicts so caller can index by keys safely.
    """
    abn = []
    for t in tests:
        name = t.get("canonical")
        val = t.get("value_num")
        if name in REFERENCE_RANGES and val is not None:
            low, high, unit = REFERENCE_RANGES[name]
            if val < low:
                abn.append({"test": name, "flag": "low", "value": val, "unit": unit})
            elif val > high:
                abn.append({"test": name, "flag": "high", "value": val, "unit": unit})
    return abn


def generate_brief_condition_summary(struct):
    """
    Always returns a dict:
      {"summary": str, "insights": list}
    """
    report_type = struct.get("report_type", "clinical")
    impression = struct.get("impression", "").strip()
    tests = struct.get("tests", []) or []

    # --- BLOOD REPORT ---
    if report_type == "blood":
        if not tests:
            return {
                "summary": "This appears to be a blood report, but no readable lab values were found.",
                "insights": []
            }

        abnormalities = interpret_abnormalities(tests)
        insights = []
        parts = []

        # Priority lab order
        priority = ["Hemoglobin", "Glucose", "WBC", "Platelets", "Creatinine"]
        seen = set()

        for p in priority:
            for t in tests:
                if t.get("canonical") == p and t.get("value"):
                    val = t.get("value")
                    unit = t.get("unit") or ""
                    found = next((a for a in abnormalities if a.get("test") == p), None)

                    if found:
                        flag = found.get("flag")
                        if flag == "low":
                            parts.append(f"{p} is low ({found['value']} {found['unit']}). This may indicate anemia or deficiency.")
                        else:
                            parts.append(f"{p} is high ({found['value']} {found['unit']}). This may indicate infection or other causes.")
                        insights.append(f"{p}: {flag} — {found['value']} {found['unit']}")
                    else:
                        parts.append(f"{p} is {val} {unit}, within normal range.")
                    seen.add(p)
                    break

        # other abnormalities (not in priority)
        for a in abnormalities:
            if a.get("test") in seen:
                continue
            insights.append(f"{a.get('test')}: {a.get('flag')} — {a.get('value')} {a.get('unit')}")

        summary = " ".join(parts[:6]) if parts else "Blood report detected. No major abnormalities found."

        if insights:
            summary += " Please discuss abnormal values with a clinician."

        return {"summary": summary, "insights": insights}

    # --- DISCHARGE SUMMARY ---
    if report_type == "discharge":
        if impression:
            cleaned = []
            for line in impression.splitlines():
                if not re.search(r"(hospital|doctor|dr\.|md|consultant|institute)", line, flags=re.IGNORECASE):
                    cleaned.append(line.strip())
            text = " ".join(cleaned).strip()[:300]
            return {"summary": text, "insights": []}
        return {"summary": "Discharge summary found, but clinical details were unclear.", "insights": []}

    # --- GENERAL CLINICAL REPORT ---
    if impression:
        return {"summary": impression.split("\n")[0], "insights": []}

    return {"summary": "The system could not detect clear medical details in the document.", "insights": []}
