from PIL import Image, ImageOps, ImageFilter
import pytesseract, shutil

def preprocess(img: Image.Image):
    img = img.convert("L")
    img = ImageOps.autocontrast(img)
    img = img.filter(ImageFilter.SHARPEN)
    w, h = img.size
    if w < 900:
        img = img.resize((w*2, h*2))
    return img

def extract_text_from_image(img: Image.Image) -> str:
    if shutil.which("tesseract") is None:
        return ""

    try:
        img = preprocess(img)
        return pytesseract.image_to_string(img, lang="eng", config="--psm 6")
    except:
        return ""
