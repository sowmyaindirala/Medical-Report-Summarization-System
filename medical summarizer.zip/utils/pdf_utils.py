
# utils/pdf_utils.py
"""
PDF utilities: extract text using pdfplumber if available; fallback strategy to OCR image per page.
This simplified implementation assumes pdfplumber is installed where used.
"""
import pdfplumber
from typing import List
from PIL import Image
from .ocr_utils import extract_text_from_image

def extract_text_from_pdf(pdf_path: str) -> str:
    out_pages = []
    with pdfplumber.open(pdf_path) as pdf:
        for page in pdf.pages:
            try:
                txt = page.extract_text()
                if txt and txt.strip():
                    out_pages.append(txt.strip())
                else:
                    # fallback to rendering page image and OCR
                    im = page.to_image(resolution=200).original
                    ocr_txt = extract_text_from_image(im)
                    if ocr_txt and ocr_txt.strip():
                        out_pages.append(ocr_txt.strip())
            except Exception:
                continue
    return "\n\n".join(out_pages).strip()
